function menubar()
{
	document.getElementById("div1").style.display="block";
	document.getElementById("open1").style.display="none";
}
function menubarclose()
{
    document.getElementById("div1").style.display="none";
    document.getElementById("open1").style.display="block";   	
}